These scripts create a database user and sample data for the examples in 
Oracle ADF Enterprise Application Development - Made Simple
ISBN 978-1-849681-88-9

First run CREATE_XDM_USER.SQL as a user with DBA privileges (e.g. SYSTEM). 
Then log on to the XDM user (default password XDM) and run XDM.SQL.
This version of the scripts contains all constraints, which were missing 
from an earlier version

(c) Sten Vesterli 2011, sten@vesterli.com
www.enterpriseadf.com, www.vesterli.com
